// #region Algemeen
//const IP = prompt('geef publiek IP', 'http://127.0.0.1:5000');
const IP = window.location.hostname + ':5000';
const socket = io.connect(IP);


const init = function() {};

document.addEventListener('DOMContentLoaded', function() {
  console.info('DOM geladen');
  init();
});

// #endregion
