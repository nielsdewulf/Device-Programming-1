from flask import Flask, jsonify
from flask_socketio import SocketIO
from flask_cors import CORS

# Code voor led
from helpers.klasseknop import Button
from RPi import GPIO
import time

led1 = 21
knop1 = Button(20)

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(led1, GPIO.OUT)

app = Flask(__name__)
CORS(app)
socketio = SocketIO(app)


@app.route('/')
def hallo():
    return "Server is running"


@socketio.on("connect")
def connecting():
    socketio.emit("connected")
    print("Connection with client established")


def lees_knop(pin):
    if GPIO.input(led1) == 1:
        GPIO.output(led1, GPIO.LOW)
    else:
        GPIO.output(led1, GPIO.HIGH)
    print("button pressed")


knop1.on_press(lees_knop)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port="5000")
